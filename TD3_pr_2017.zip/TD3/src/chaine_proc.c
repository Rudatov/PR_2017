#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc,char** args){
	if(argc != 2 ){
		perror("Probleme d'argument\n");
		return -1;
	}
	int N = atoi(args[1]);
	pid_t pids[N];
	pids[0]=getpid();
	int exit_val,i;
//1. chaine de proc
//2. passer le pid
//3. quel code ?

	for(i=0;i<N;i++){
		int p=fork();
		if(p==-1){
			perror("erreur fork \n");
			exit(errno);
		}//perror
		if(p!=0){
			pids[i+1]=p;
			break;
		}else{

			pids[i+1]=getpid();

		}
	}
	if(getpid()==pids[0]){
//Pere
		wait(&exit_val);
		printf("aleatoire : %d \n",exit_val);
		exit(0);

	}else if(i==N){
//Final
//impression de tous les pids
		for(int j=0;j<N;j++){
			if(j==N-1){
				printf("%d",pids[j]);
			}else{
				printf("%d | ",pids[j]);
			}
		}
		printf("\n");
		int le_random;
		le_random=(int)(rand()/(((double)RAND_MAX + 1)/100));
		exit(le_random);
	}
	else{
//intermediaire
//impression pid pere/soi-meme/fils
		
		printf("Pere : %d | Self : %d | Fils : %d \n",pids[i-1],getpid(),pids[i+1]);
		wait(&exit_val);
		exit(WEXITSTATUS(exit_val));
	}
	return 0;
}
