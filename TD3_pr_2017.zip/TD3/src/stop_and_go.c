//stop_and_go.c
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

//dernier 
// utiliser handler(SIG);
///proccessus fils autostop , -> kill(getpid(),SIGSTOP); // renvois de SIGCHLD
//proc intermed sautokill quand recoit SIGCHLD
// pere recoit SIGCHILD fais affichage et debloque son fils direct qui va debloquer le sien et ainsi de suite
//handle --> SIGCHLD : se stopper |||| si pere SIGCONT sur fils
//attente :
//body intermed :
	sigsuspend(SIGCHLD);
	kill(fils,SIGCONT);
	exit(0);

	//pour handler  sa_action , pointeur de fonction

	//creer var globale pour reconnaitre pere intial , handler fonction hors du main.