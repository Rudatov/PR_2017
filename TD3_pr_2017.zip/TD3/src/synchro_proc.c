//synchro_proc.c
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

//1. P2 signaler a P1
//2. P2 kill et envois sigchld
//3. p1 signale p3 mort a p1
//4. p1 se kill
//5. p0 prend conscience de la mort de p2 et affiche
void handler(int signal){
	printf("\n");
}
int main(int argc,char* argv){
	int exit_val,i;
	sigset_t test_set;
	// creer deux set usr ou gerer ordre des sigdelset
	sigfillset(&test_set);
	sigdelset(&test_set,SIGUSR1);
	sigdelset(&test_set,SIGUSR2);
	int p, p2;
	p=fork();
	if(p!=0){
		//pere
		sigsuspend(&test_set);
		//affiche p3 mort (usr2)
		//sigsuspend(usr1)
		//affichage p2 mort
	}else{
		struct sigaction sa;
		sa.sa_handler = handler;
		p2 = fork();
		if(p2!=0){
			sigaction(SIGUSR1,&sa,NULL);
			//fils
		}else{
			sigaction(SIGUSR2,&sa,NULL);
			//petit_fils
		}
	}


	return 0;
}

//P2. kill(p0, USR1)
// 		exit (0);

//P1. sigsuspend(chld) ou wait()
//	  kill (p0,usr2)
//

//P0. Handler USR1 -> afficher P2 mort
//  			USR2 --> afficher p1 mort 
//masquerr usr1 et usr2
//demasquer et sigsuspend usr1
//demasquer et sigsuspend usr2